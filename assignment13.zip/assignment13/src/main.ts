const header = document.getElementById('GameName') as HTMLHeadingElement;
const squares = document.getElementsByClassName('square') as HTMLCollectionOf<HTMLDivElement>;
const players = ['X', 'O'];
let currentPlayer = players[0];
let gameOver = false;

const endMessage = document.createElement('h4');
endMessage.style.marginTop = '20px';
endMessage.style.textAlign = 'center';
header.appendChild(endMessage);

const winning_combinations = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];


function loadGameState() {
    const savedBoard = localStorage.getItem("ticTacToeBoard");
    const savedPlayer = localStorage.getItem("ticTacToePlayer");
    const savedGameOver = localStorage.getItem("ticTacToeGameOver");

    if (savedBoard && savedPlayer && savedGameOver) {
        const boardState = JSON.parse(savedBoard);
        for (let i = 0; i < squares.length; i++) {
            squares[i].textContent = boardState[i];
        }
        currentPlayer = savedPlayer;
        gameOver = savedGameOver === "true";
        endMessage.textContent = `${currentPlayer}'s turn!`;
    } else {
        endMessage.textContent = "X's turn!";
    }
}


function saveGameState() {
    const boardState = Array.from(squares).map(square => square.textContent);
    localStorage.setItem("ticTacToeBoard", JSON.stringify(boardState));
    localStorage.setItem("ticTacToePlayer", currentPlayer);
    localStorage.setItem("ticTacToeGameOver", gameOver.toString());
}


for (let i = 0; i < squares.length; i++) {
    squares[i].addEventListener('click', () => {
        if (squares[i].textContent !== '' || gameOver) {
            return;
        }
        squares[i].textContent = currentPlayer;

        if (checkWin(currentPlayer)) {
            endMessage.textContent = `Game over! ${currentPlayer} wins!`;
            gameOver = true;
            saveGameState();
            return;
        }

        if (checkTie()) {
            endMessage.textContent = "Game is tied!";
            gameOver = true;
            saveGameState();
            return;
        }

        currentPlayer = (currentPlayer === players[0]) ? players[1] : players[0];
        endMessage.textContent = `${currentPlayer}'s turn!`;
        saveGameState();
    });
}


function checkWin(currentPlayer: string): boolean {
    for (let i = 0; i < winning_combinations.length; i++) {
        const [a, b, c] = winning_combinations[i];
        if (squares[a].textContent === currentPlayer && squares[b].textContent === currentPlayer && squares[c].textContent === currentPlayer) {
            return true;
        }
    }
    return false;
}


function checkTie(): boolean {
    return Array.from(squares).every(square => square.textContent !== '');
}


function restartButton() {
    for (let i = 0; i < squares.length; i++) {
        squares[i].textContent = "";
    }
    endMessage.textContent = "X's turn!";
    currentPlayer = players[0];
    gameOver = false;

    
    localStorage.removeItem("ticTacToeBoard");
    localStorage.removeItem("ticTacToePlayer");
    localStorage.removeItem("ticTacToeGameOver");
}


loadGameState();